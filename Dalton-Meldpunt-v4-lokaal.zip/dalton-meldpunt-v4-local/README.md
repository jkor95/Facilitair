# Dalton Meldpunt v4 - volledig lokaal

Dalton Meldpunt is een statische PWA voor GitHub Pages. Er is geen Supabase, Cloudflare, externe database of externe accountdienst nodig.

## Standaard hoofdbeheer

Bij de eerste start:

- Gebruikersnaam: `Admin`
- Wachtwoord: `Admin`

Na inloggen kun je beide aanpassen via **Beheer > Medewerkers & accounts > Bekijken / bewerken**.

Als je jezelf buitensluit, staat op het lokale inlogscherm de knop **Herstel Admin / Admin**. Die herstelt alleen het hoofdbeheeraccount op dat apparaat en laat bestaande meldingen staan.

## Wat staat lokaal?

Op het gebruikte apparaat/in de gebruikte browser worden lokaal opgeslagen:

- accounts en wachtwoorden;
- meldingen;
- foto's;
- statussen en toewijzingen;
- automatische categorie-toewijzing;
- interne notities;
- auditlog;
- appinstellingen.

Hoofdbeheer kan wachtwoorden inzien en wijzigen. Dit is op verzoek bewust zo gebouwd. Daardoor staan wachtwoorden leesbaar in de lokale appgegevens. Gebruik voor deze app daarom nooit hetzelfde wachtwoord als voor Microsoft 365, e-mail of andere belangrijke accounts.

## Belangrijke beperking van volledig lokaal

GitHub Pages is alleen de statische app. Er is geen centrale database.

Daarom geldt: een melding die op apparaat A wordt gemaakt, verschijnt niet vanzelf op apparaat B. Elk apparaat heeft zijn eigen lokale gegevens. Voor gebruik door meerdere medewerkers op verschillende telefoons is later een gedeelde server nodig. Dat kan eventueel ook een lokale schoolserver zijn; daarvoor is geen Cloudflare of Supabase vereist.

## E-mail

De app opent ingevulde e-mails via de standaard mail-app (`mailto:`). Een volledig lokale webapp kan niet zelfstandig op de achtergrond e-mails versturen zonder een mailserver of externe maildienst.

## Back-up

Via **Beheer > Lokale back-up** kun je alle lokale gegevens exporteren als JSON en later weer importeren.

## Auditlog

Hoofdbeheer ziet de volledige auditlog in tekst. Je kunt een periode kiezen met **Van** en **Tot en met** en die periode als PDF exporteren.

## Publiceren op GitHub Pages

1. Maak een GitHub repository, bijvoorbeeld `dalton-meldpunt`.
2. Upload alle bestanden uit deze map naar de root van de repository.
3. Ga naar **Settings > Pages**.
4. Kies **Deploy from a branch**.
5. Kies `main` en `/root`.
6. Open daarna de GitHub Pages-link.
7. Pas eventueel `assets/config.js` aan voor schoolnaam, conciërge-e-mailadres en de definitieve openbare URL.

## iPhone

Open de GitHub Pages-link in Safari en kies **Deel > Zet op beginscherm**.

De PWA kan lokale badges/browsermeldingen gebruiken waar iOS dit ondersteunt. Omdat de gegevens niet centraal zijn, kan een ander apparaat geen nieuwe melding naar deze lokale installatie pushen.
