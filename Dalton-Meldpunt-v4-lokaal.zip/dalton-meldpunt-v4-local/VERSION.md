# Dalton Meldpunt v4 lokaal

- Volledig lokale opslag; geen Cloudflare en geen Supabase.
- Standaard hoofdbeheerlogin: `Admin` / `Admin`.
- Herstelknop voor lokaal hoofdbeheeraccount.
- Hoofdbeheer kan gebruikersnamen, rollen, status en wachtwoorden inzien en wijzigen.
- Geen minimale wachtwoordlengte; elk niet-leeg wachtwoord is toegestaan.
- Meldingen, foto's, routing en auditlog blijven lokaal op het apparaat.
- Auditlogtekst + PDF-export met Van/Tot-datum.
- Personeelsformulier heeft één vrij veld voor locatie/lokaal/ruimte.
- Facilitair kan bij afronden kiezen of een mailconcept voor de melder wordt geopend.
- JSON-export/import voor lokale back-up.
